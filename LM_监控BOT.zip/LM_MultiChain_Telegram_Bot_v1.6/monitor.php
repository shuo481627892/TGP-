<?php
// 多链监听进程：php monitor.php
// 单次检查：php monitor.php once
require __DIR__ . '/bootstrap.php';
@set_time_limit(0);
@ignore_user_abort(true);

/**
 * 监听地址发生收支时，只给添加该地址的用户推送。
 * 推送内容重点展示：监听地址、本次收入/支出、交易后该币种余额。
 */
function notifyTransaction(Telegram $telegram, ChainProviders $providers, array $config, array $addr, array $tx): void
{
    $direction = strtoupper((string)($tx['direction'] ?? 'IN'));
    $isIn = $direction === 'IN';
    $chain = (string)($tx['chain'] ?? (string)$addr['chain']);
    $symbol = (string)($tx['symbol'] ?? Utils::nativeSymbol($chain));
    $amount = (string)($tx['amount'] ?? '0');
    $watchAddress = (string)($tx['address'] ?? (string)$addr['address']);
    $from = (string)($tx['from_addr'] ?? '');
    $to = (string)($tx['to_addr'] ?? '');
    $peer = $isIn ? $from : $to;
    $txid = (string)($tx['txid'] ?? '');
    $url = Utils::explorerUrl($chain, $txid);

    $title = $isIn ? '🟢 监听地址收入提醒' : '🔴 监听地址支出提醒';
    $changeLabel = $isIn ? '📥 地址收入' : '📤 地址支出';
    $balanceLabel = $isIn ? '💼 收入后余额' : '💼 支出后余额';
    $directionText = $isIn ? '收入' : '支出';
    $signedChange = Utils::formatSigned($direction, $amount);
    $label = trim((string)($addr['label'] ?? ''));

    $balanceText = '未获取';
    try {
        // 查询本次转账币种的当前余额：USDT 转账查 USDT 余额，TRX 转账查 TRX 余额，BTC 转账查 BTC 余额。
        $balance = $providers->getPostTxBalance($tx);
        if (is_array($balance) && ($balance['ok'] ?? true)) {
            $balanceText = Utils::formatBalanceValue((string)($balance['balance'] ?? '0'), (string)($balance['symbol'] ?? $symbol));
        } elseif (is_array($balance)) {
            $balanceText = (string)($balance['balance'] ?? '未获取');
        }
    } catch (Throwable $e) {
        $balanceText = '查询失败：' . $e->getMessage();
    }

    $text = "<b>{$title}</b>\n\n" .
        "👛 监听地址：<code>" . Utils::h($watchAddress) . "</code>\n" .
        ($label !== '' ? "🏷 备注：<b>" . Utils::h($label) . "</b>\n" : '') .
        "⛓ 监听链：<b>" . Utils::h(Utils::chainTitle($chain)) . "</b>\n" .
        "📌 收支类型：<b>" . Utils::h($directionText) . "</b>\n" .
        "💰 币种：<b>" . Utils::h($symbol) . "</b>\n" .
        "{$changeLabel}：<b>" . Utils::h($amount) . ' ' . Utils::h($symbol) . "</b>\n" .
        "📊 净变动：<b>" . Utils::h($signedChange) . ' ' . Utils::h($symbol) . "</b>\n" .
        "{$balanceLabel}：<b>" . Utils::h($balanceText) . "</b>\n\n" .
        "📤 转出地址：<code>" . Utils::h($from ?: '-') . "</code>\n" .
        "📥 收入地址：<code>" . Utils::h($to ?: '-') . "</code>\n" .
        "👤 对方地址：<code>" . Utils::h($peer ?: '-') . "</code>\n" .
        "🧾 交易哈希：<a href=\"" . Utils::h($url) . "\">" . Utils::h(Utils::short($txid, 12, 10)) . "</a>\n" .
        "⏰ 时间：" . Utils::h((string)($tx['block_time'] ?? Utils::now())) . "\n\n" .
        Utils::h($config['copyright'] ?? '@Addliming');

    $keyboard = [[['text' => '🔎 查看交易详情', 'url' => $url]]];
    $telegram->sendMessage((string)$addr['chat_id'], $text, $keyboard, false);
}

function runOnce(DB $db, Telegram $telegram, ChainProviders $providers, array $config): void
{
    $limit = (int)($config['fetch_limit'] ?? 10);
    foreach ($db->activeAddresses() as $addr) {
        $addr['chain'] = Utils::normalizeChain((string)$addr['chain']) ?: (string)$addr['chain'];
        $addr['address'] = trim((string)$addr['address']);

        // 防止数据库里已有的错误地址反复请求接口造成刷屏。发现无效地址后自动停用，并通知添加者重新添加。
        if (!Utils::validateAddress((string)$addr['chain'], (string)$addr['address'])) {
            $msg = 'invalid address deactivated #' . ($addr['id'] ?? '') . ' ' . $addr['chain'] . ' ' . $addr['address'];
            $db->log('WARN', $msg);
            if (!empty($addr['id'])) $db->deactivateAddress((int)$addr['id']);
            try {
                $telegram->sendMessage((string)$addr['chat_id'],
                    "⚠️ <b>监听地址已自动停用</b>

" .
                    "原因：地址格式或校验位错误，链上接口拒绝查询。
" .
                    "监听链：<b>" . Utils::h(Utils::chainTitle((string)$addr['chain'])) . "</b>
" .
                    "地址：<code>" . Utils::h((string)$addr['address']) . "</code>

" .
                    "请复制完整正确地址后重新添加。

" . Utils::h($config['copyright'] ?? '@Addliming')
                );
            } catch (Throwable $e) {}
            echo '[' . Utils::now() . '] ' . $msg . PHP_EOL;
            usleep(200000);
            continue;
        }

        try {
            $txs = $providers->fetchTransactions($addr['chain'], $addr['address'], $limit);
            // API 通常按新到旧返回，这里反转后从旧到新发，避免通知顺序乱。
            usort($txs, fn($a, $b) => ($a['timestamp'] ?? 0) <=> ($b['timestamp'] ?? 0));
            foreach ($txs as $tx) {
                $isNew = $db->insertTx($tx, 0);
                if ($isNew) {
                    notifyTransaction($telegram, $providers, $config, $addr, $tx);
                    $db->markNotified($tx['unique_key']);
                    echo '[' . Utils::now() . '] notify ' . $addr['chat_id'] . ' ' . $addr['chain'] . ' ' . $addr['address'] . ' ' . ($tx['direction'] ?? '') . ' ' . ($tx['amount'] ?? '') . ' ' . ($tx['symbol'] ?? '') . ' ' . $tx['txid'] . PHP_EOL;
                }
            }
        } catch (Throwable $e) {
            $db->log('ERROR', 'monitor ' . $addr['chain'] . ' ' . $addr['address'] . ': ' . $e->getMessage());
            echo '[' . Utils::now() . '] monitor failed ' . $addr['chain'] . ' ' . $addr['address'] . ': ' . $e->getMessage() . PHP_EOL;
        }
        usleep(200000);
    }
}

if (($argv[1] ?? '') === 'once') {
    runOnce($db, $telegram, $providers, $config);
    exit;
}

echo "LM MultiChain monitor started. " . Utils::now() . PHP_EOL;
$interval = max(5, (int)($config['monitor_interval'] ?? 20));
while (true) {
    @file_put_contents(__DIR__ . '/storage/monitor.heartbeat', Utils::now());
    try {
        runOnce($db, $telegram, $providers, $config);
    } catch (Throwable $e) {
        $db->log('ERROR', 'monitor loop crashed but recovered: ' . $e->getMessage());
        echo '[' . Utils::now() . '] monitor loop crashed but recovered: ' . $e->getMessage() . PHP_EOL;
    }
    sleep($interval);
}
