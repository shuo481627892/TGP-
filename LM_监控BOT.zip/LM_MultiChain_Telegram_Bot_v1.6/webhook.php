<?php
// Telegram Webhook 入口：把 Nginx/Apache 指向此文件，或放到 public 目录外自行引入
require __DIR__ . '/bootstrap.php';
$raw = file_get_contents('php://input');
$update = json_decode($raw, true);
if (is_array($update)) {
    $controller->handleUpdate($update);
}
echo 'OK';
