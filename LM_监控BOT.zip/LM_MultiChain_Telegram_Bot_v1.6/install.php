<?php
require __DIR__ . '/bootstrap.php';
@mkdir(__DIR__ . '/storage', 0755, true);
echo "LM MultiChain Telegram Bot installed.\n";
echo "DB: " . $config['db_path'] . "\n";
echo "Next: edit config.php then run php bot.php and php monitor.php\n";
