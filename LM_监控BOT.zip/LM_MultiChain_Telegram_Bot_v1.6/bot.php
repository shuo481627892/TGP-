<?php
// Telegram 长轮询入口：php bot.php
require __DIR__ . '/bootstrap.php';
@set_time_limit(0);
@ignore_user_abort(true);

echo "LM MultiChain Telegram Bot long polling started. " . Utils::now() . PHP_EOL;
$offset = 0;
$pollTimeout = max(10, (int)($config['telegram_poll_timeout'] ?? 25));
$curlTimeout = max($pollTimeout + 20, (int)($config['telegram_request_timeout'] ?? 75));
while (true) {
    @file_put_contents(__DIR__ . '/storage/bot.heartbeat', Utils::now());
    try {
        $res = $telegram->api('getUpdates', [
            'offset' => $offset,
            'timeout' => $pollTimeout,
            'allowed_updates' => json_encode(['message', 'callback_query'], JSON_UNESCAPED_UNICODE),
        ], $curlTimeout);
        foreach (($res['result'] ?? []) as $update) {
            $offset = max($offset, (int)$update['update_id'] + 1);
            try {
                $controller->handleUpdate($update);
            } catch (Throwable $e) {
                $db->log('ERROR', 'update failed: ' . $e->getMessage());
                $chatId = (string)($update['message']['chat']['id'] ?? $update['callback_query']['message']['chat']['id'] ?? '');
                if ($chatId !== '') {
                    try { $telegram->sendMessage($chatId, '❌ 处理失败：' . Utils::h($e->getMessage())); } catch (Throwable $ignore) {}
                }
            }
        }
    } catch (Throwable $e) {
        $db->log('ERROR', 'polling failed: ' . $e->getMessage());
        echo '[' . Utils::now() . '] polling failed: ' . $e->getMessage() . PHP_EOL;
        sleep(5);
    }
}
