#!/usr/bin/env bash
set -u

APP_DIR="${1:-$(cd "$(dirname "$0")/.." && pwd)}"
APP_DIR="$(cd "$APP_DIR" 2>/dev/null && pwd || echo "$APP_DIR")"
MAX_AGE="${HEARTBEAT_MAX_AGE:-180}"
BOT_SERVICE="lm-multichain-bot.service"
MONITOR_SERVICE="lm-multichain-monitor.service"
NOW_TS="$(date +%s)"

log() {
  echo "[$(date '+%F %T')] $*"
  command -v logger >/dev/null 2>&1 && logger -t lm-multichain-watchdog "$*" || true
}

restart_service() {
  local svc="$1"
  local reason="$2"
  log "restart $svc: $reason"
  systemctl restart "$svc" || log "failed to restart $svc"
}

check_service() {
  local svc="$1"
  local hb="$2"

  if ! systemctl is-active --quiet "$svc"; then
    restart_service "$svc" "service is not active"
    return
  fi

  if [ ! -f "$hb" ]; then
    restart_service "$svc" "heartbeat file missing: $hb"
    return
  fi

  local hb_ts
  hb_ts="$(date -d "$(cat "$hb" 2>/dev/null)" +%s 2>/dev/null || stat -c %Y "$hb" 2>/dev/null || echo 0)"
  local age=$((NOW_TS - hb_ts))

  if [ "$age" -gt "$MAX_AGE" ]; then
    restart_service "$svc" "heartbeat timeout: ${age}s > ${MAX_AGE}s"
  else
    log "$svc ok, heartbeat age ${age}s"
  fi
}

check_service "$BOT_SERVICE" "$APP_DIR/storage/bot.heartbeat"
check_service "$MONITOR_SERVICE" "$APP_DIR/storage/monitor.heartbeat"
