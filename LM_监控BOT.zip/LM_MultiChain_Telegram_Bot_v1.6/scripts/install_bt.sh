#!/usr/bin/env bash
set -e
APP_DIR=${1:-/www/wwwroot/LM_MultiChain_Telegram_Bot}
PHP_BIN=${PHP_BIN:-php}
cd "$APP_DIR"
if [ ! -f config.php ]; then
  cp config.example.php config.php
  echo "已生成 config.php，请先编辑 Token 和 API Key：$APP_DIR/config.php"
fi
mkdir -p storage
chmod -R 755 storage
$PHP_BIN install.php
echo "\n前台测试："
echo "cd $APP_DIR && php bot.php"
echo "cd $APP_DIR && php monitor.php once"
echo "\n生产环境建议使用 systemd 或 supervisor 守护 bot.php 与 monitor.php。"
