#!/usr/bin/env bash
journalctl -u lm-multichain-bot -u lm-multichain-monitor -u lm-multichain-watchdog -f
