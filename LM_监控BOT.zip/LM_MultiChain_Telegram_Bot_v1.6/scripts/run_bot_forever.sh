#!/usr/bin/env bash
set -u
APP_DIR="${1:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$APP_DIR" || exit 1
while true; do
  echo "[$(date '+%F %T')] bot.php starting..."
  php bot.php
  code=$?
  echo "[$(date '+%F %T')] bot.php exited: $code, restart after 5s..."
  sleep 5
done
