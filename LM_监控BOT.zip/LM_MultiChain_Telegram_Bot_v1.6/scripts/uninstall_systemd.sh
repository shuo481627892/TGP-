#!/usr/bin/env bash
set -euo pipefail
systemctl stop lm-multichain-bot lm-multichain-monitor lm-multichain-watchdog.timer 2>/dev/null || true
systemctl disable lm-multichain-bot lm-multichain-monitor lm-multichain-watchdog.timer 2>/dev/null || true
rm -f /etc/systemd/system/lm-multichain-bot.service \
      /etc/systemd/system/lm-multichain-monitor.service \
      /etc/systemd/system/lm-multichain-watchdog.service \
      /etc/systemd/system/lm-multichain-watchdog.timer
systemctl daemon-reload
echo "已卸载 systemd 守护服务和 watchdog。"
