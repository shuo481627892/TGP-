#!/usr/bin/env bash
set -u
APP_DIR="${1:-$(cd "$(dirname "$0")/.." && pwd)}"
cd "$APP_DIR" || exit 1
while true; do
  echo "[$(date '+%F %T')] monitor.php starting..."
  php monitor.php
  code=$?
  echo "[$(date '+%F %T')] monitor.php exited: $code, restart after 5s..."
  sleep 5
done
