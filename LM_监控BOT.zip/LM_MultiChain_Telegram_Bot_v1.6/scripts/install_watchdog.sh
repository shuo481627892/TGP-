#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${1:-$(cd "$(dirname "$0")/.." && pwd)}"
APP_DIR="$(cd "$APP_DIR" && pwd)"
if [ ! -f "$APP_DIR/scripts/watchdog.sh" ]; then
  echo "未找到 $APP_DIR/scripts/watchdog.sh" >&2
  exit 1
fi
chmod +x "$APP_DIR/scripts/watchdog.sh"
cat > /etc/systemd/system/lm-multichain-watchdog.service <<EOF2
[Unit]
Description=LM MultiChain Watchdog
After=network-online.target lm-multichain-bot.service lm-multichain-monitor.service

[Service]
Type=oneshot
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/env HEARTBEAT_MAX_AGE=180 $APP_DIR/scripts/watchdog.sh $APP_DIR
User=root
Group=root
StandardOutput=journal
StandardError=journal
EOF2
cat > /etc/systemd/system/lm-multichain-watchdog.timer <<EOF2
[Unit]
Description=Run LM MultiChain Watchdog every minute

[Timer]
OnBootSec=120
OnUnitActiveSec=60
AccuracySec=15
Unit=lm-multichain-watchdog.service

[Install]
WantedBy=timers.target
EOF2
systemctl daemon-reload
systemctl enable lm-multichain-watchdog.timer >/dev/null
systemctl restart lm-multichain-watchdog.timer
systemctl status lm-multichain-watchdog.timer --no-pager
