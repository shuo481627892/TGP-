#!/usr/bin/env bash
systemctl status lm-multichain-bot lm-multichain-monitor lm-multichain-watchdog.timer --no-pager
