#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${1:-$(cd "$(dirname "$0")/.." && pwd)}"
APP_DIR="$(cd "$APP_DIR" && pwd)"
PHP_BIN="${PHP_BIN:-$(command -v php || true)}"
SERVICE_USER="${SERVICE_USER:-root}"
SERVICE_GROUP="${SERVICE_GROUP:-root}"
BOT_SERVICE="lm-multichain-bot.service"
MONITOR_SERVICE="lm-multichain-monitor.service"

if [ -z "$PHP_BIN" ]; then
  echo "未找到 php 命令，请先安装 PHP CLI，或这样指定：PHP_BIN=/www/server/php/80/bin/php bash scripts/install_systemd.sh $APP_DIR" >&2
  exit 1
fi
if [ ! -f "$APP_DIR/bot.php" ] || [ ! -f "$APP_DIR/monitor.php" ]; then
  echo "目录不正确：$APP_DIR，未找到 bot.php / monitor.php" >&2
  exit 1
fi
if [ ! -f "$APP_DIR/config.php" ]; then
  cp "$APP_DIR/config.example.php" "$APP_DIR/config.php"
  echo "已生成 $APP_DIR/config.php，请先填写 Telegram Token 和 API Key 后再启动。"
fi

mkdir -p "$APP_DIR/storage"
chmod -R 755 "$APP_DIR/storage"

# 停止手动残留进程，避免 Telegram getUpdates 冲突或重复通知。
pkill -f "php .*${APP_DIR}/bot.php" 2>/dev/null || true
pkill -f "php .*${APP_DIR}/monitor.php" 2>/dev/null || true
pkill -f "php bot.php" 2>/dev/null || true
pkill -f "php monitor.php" 2>/dev/null || true

cat > "/etc/systemd/system/$BOT_SERVICE" <<EOF
[Unit]
Description=LM MultiChain Telegram Bot
After=network-online.target
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
WorkingDirectory=$APP_DIR
ExecStart=$PHP_BIN $APP_DIR/bot.php
Restart=always
RestartSec=5
KillSignal=SIGINT
TimeoutStopSec=30
User=$SERVICE_USER
Group=$SERVICE_GROUP
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

cat > "/etc/systemd/system/$MONITOR_SERVICE" <<EOF
[Unit]
Description=LM MultiChain Address Monitor
After=network-online.target lm-multichain-bot.service
Wants=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
WorkingDirectory=$APP_DIR
ExecStart=$PHP_BIN $APP_DIR/monitor.php
Restart=always
RestartSec=5
KillSignal=SIGINT
TimeoutStopSec=30
User=$SERVICE_USER
Group=$SERVICE_GROUP
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# 心跳 watchdog：systemd 只能在进程退出时自动重启；如果进程卡死但没有退出，就由 timer 检测 heartbeat 并重启。
cat > "/etc/systemd/system/lm-multichain-watchdog.service" <<EOF
[Unit]
Description=LM MultiChain Watchdog
After=network-online.target lm-multichain-bot.service lm-multichain-monitor.service

[Service]
Type=oneshot
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/env HEARTBEAT_MAX_AGE=180 $APP_DIR/scripts/watchdog.sh $APP_DIR
User=root
Group=root
StandardOutput=journal
StandardError=journal
EOF

cat > "/etc/systemd/system/lm-multichain-watchdog.timer" <<EOF
[Unit]
Description=Run LM MultiChain Watchdog every minute

[Timer]
OnBootSec=120
OnUnitActiveSec=60
AccuracySec=15
Unit=lm-multichain-watchdog.service

[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable "$BOT_SERVICE" "$MONITOR_SERVICE" lm-multichain-watchdog.timer >/dev/null
systemctl restart "$BOT_SERVICE" "$MONITOR_SERVICE"
systemctl restart lm-multichain-watchdog.timer

echo "守护进程和心跳 watchdog 已安装并启动："
systemctl --no-pager --full status "$BOT_SERVICE" "$MONITOR_SERVICE" lm-multichain-watchdog.timer | sed -n '1,120p'
echo
echo "查看运行状态：systemctl status $BOT_SERVICE $MONITOR_SERVICE lm-multichain-watchdog.timer"
echo "查看实时日志：journalctl -u $BOT_SERVICE -u $MONITOR_SERVICE -u lm-multichain-watchdog -f"
echo "手动执行心跳检测：bash $APP_DIR/scripts/watchdog.sh $APP_DIR"
echo "停止：systemctl stop $BOT_SERVICE $MONITOR_SERVICE lm-multichain-watchdog.timer"
echo "重启：systemctl restart $BOT_SERVICE $MONITOR_SERVICE"
