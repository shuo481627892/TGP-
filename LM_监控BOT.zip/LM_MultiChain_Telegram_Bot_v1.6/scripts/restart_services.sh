#!/usr/bin/env bash
systemctl restart lm-multichain-bot lm-multichain-monitor
systemctl status lm-multichain-bot lm-multichain-monitor --no-pager
