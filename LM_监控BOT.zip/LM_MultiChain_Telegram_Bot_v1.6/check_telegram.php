<?php
// Telegram 连通性检测：php check_telegram.php
require __DIR__ . '/bootstrap.php';

echo "LM Telegram check started. " . Utils::now() . PHP_EOL;
echo "Proxy: " . (($config['proxy'] ?? '') !== '' ? $config['proxy'] : '未设置') . PHP_EOL;
echo "Force IPv4: " . (!empty($config['telegram_force_ipv4']) ? 'yes' : 'no') . PHP_EOL;

try {
    $res = $telegram->api('getMe', [], 25);
    $bot = $res['result'] ?? [];
    echo "✅ Telegram API 正常：@" . ($bot['username'] ?? 'unknown') . " / ID " . ($bot['id'] ?? '') . PHP_EOL;
    echo "现在可以运行：php bot.php" . PHP_EOL;
} catch (Throwable $e) {
    echo "❌ Telegram API 连接失败：" . $e->getMessage() . PHP_EOL;
    echo PHP_EOL;
    echo "排查顺序：" . PHP_EOL;
    echo "1) 检查 Token 是否正确：config.php -> telegram_bot_token" . PHP_EOL;
    echo "2) 服务器直连 Telegram 不通时，在 config.php 填 proxy，例如：http://127.0.0.1:7890" . PHP_EOL;
    echo "3) 服务器执行：curl -4 -m 20 https://api.telegram.org" . PHP_EOL;
    echo "4) 如果 curl 也超时，就是服务器网络/防火墙/DNS/代理问题，不是程序安装问题。" . PHP_EOL;
    exit(1);
}
