<?php
// 黎明多链监听机器人配置
// 复制为 config.php 后修改参数：cp config.example.php config.php
return [
    // Telegram Bot Token，从 @BotFather 获取
    'telegram_bot_token' => 'PUT_YOUR_TELEGRAM_BOT_TOKEN_HERE',

    // 管理员 Telegram ID，多个用逗号或数组。留空则所有使用者只能管理自己添加的地址。
    // 示例：[123456789, 987654321]
    'admin_ids' => [],

    // 时区
    'timezone' => 'Asia/Singapore',

    // SQLite 数据库路径，不建议放 public 目录
    'db_path' => __DIR__ . '/storage/bot.sqlite',

    // 监听间隔秒数；接口免费额度有限，地址多时建议 20-60 秒
    'monitor_interval' => 20,

    // 每次每个监听地址拉取最近交易数量；数值越大越不容易漏单，但接口消耗越高
    'fetch_limit' => 10,

    // Etherscan API V2 Key：ETH/BSC/BCS 监听需要
    // 申请：https://etherscan.io/apis
    'etherscan_api_key' => 'PUT_ETHERSCAN_V2_API_KEY_HERE',

    // TronGrid API Key：TRON/TRX/TRC20 建议填写，不填也可尝试公共接口
    // 申请：https://www.trongrid.io/
    'trongrid_api_key' => '',

    // API 基础地址，一般无需改
    'etherscan_v2_base' => 'https://api.etherscan.io/v2/api',
    'trongrid_base' => 'https://api.trongrid.io',
    'blockstream_base' => 'https://blockstream.info/api',



    // 余额查询默认显示的常用代币。你可以在 config.php 里继续追加。
    // 监听通知会优先查询本次交易币种的剩余余额：
    // 例如 USDT-TRC20 收支提醒显示 USDT 余额，TRX 收支提醒显示 TRX 余额。
    // ETH/BSC 监听到其他 ERC20/BEP20 代币转账时，也会按交易里的合约自动查询该代币剩余余额。
    'common_tokens' => [
        'ETH' => [
            ['symbol' => 'USDT', 'contract' => '0xdAC17F958D2ee523a2206206994597C13D831ec7', 'decimals' => 6],
            ['symbol' => 'USDC', 'contract' => '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606EB48', 'decimals' => 6],
        ],
        'BSC' => [
            ['symbol' => 'USDT', 'contract' => '0x55d398326f99059fF775485246999027B3197955', 'decimals' => 18],
            ['symbol' => 'USDC', 'contract' => '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', 'decimals' => 18],
        ],
        'TRON' => [
            ['symbol' => 'USDT', 'contract' => 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', 'decimals' => 6],
        ],
    ],

    // 通知底部版权
    'copyright' => '@Addliming',

    // Telegram 消息代理，可留空。国内/受限网络建议填写。
    // 示例：http://127.0.0.1:7890 或 socks5h://127.0.0.1:1080
    'proxy' => '',

    // Telegram 长轮询/请求超时配置。重点：request_timeout 必须大于 poll_timeout。
    'telegram_poll_timeout' => 25,
    'telegram_connect_timeout' => 15,
    'telegram_request_timeout' => 75,

    // 有些服务器 IPv6 到 Telegram 不通，默认强制 IPv4。
    'telegram_force_ipv4' => true,
];
