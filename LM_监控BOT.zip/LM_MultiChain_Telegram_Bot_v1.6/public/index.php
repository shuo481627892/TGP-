<?php
require dirname(__DIR__) . '/bootstrap.php';
$stats = $db->stats();
$rows = array_slice($db->listAddresses('', true), 0, 100);
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>黎明多链监听机器人</title>
<style>
:root{--bg:#05070d;--card:#0b1220;--line:#0f2d46;--cyan:#00d5ff;--text:#e8f7ff;--muted:#7ea4b8;--red:#ff4d6d;}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 20% 0,#10233b 0,#05070d 42%,#020308 100%);font-family:Arial,"Microsoft YaHei",sans-serif;color:var(--text)}
.wrap{max-width:1180px;margin:0 auto;padding:36px 18px}.hero{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:24px}.brand h1{margin:0;font-size:30px;letter-spacing:1px}.brand p{color:var(--muted);margin:10px 0 0}.badge{border:1px solid var(--cyan);padding:10px 16px;border-radius:999px;color:var(--cyan);box-shadow:0 0 22px rgba(0,213,255,.25)}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:20px 0}.card{background:linear-gradient(180deg,rgba(11,18,32,.96),rgba(5,9,18,.96));border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 12px 40px rgba(0,0,0,.35),inset 0 0 30px rgba(0,213,255,.03)}.num{font-size:32px;font-weight:700;color:var(--cyan);text-shadow:0 0 18px rgba(0,213,255,.45)}.label{color:var(--muted);margin-top:6px}
table{width:100%;border-collapse:collapse;margin-top:8px;overflow:hidden;border-radius:16px}th,td{padding:13px 12px;border-bottom:1px solid #10253a;text-align:left}th{color:var(--cyan);font-weight:600;background:#07101e}td{color:#d7eef8}.addr{font-family:monospace;color:#bcefff}.chain{display:inline-block;border:1px solid var(--line);border-radius:999px;padding:4px 10px;color:var(--cyan)}
.footer{margin-top:26px;text-align:center;color:var(--muted)}@media(max-width:800px){.hero{display:block}.grid{grid-template-columns:1fr}.badge{display:inline-block;margin-top:16px}table{font-size:13px}}
</style>
</head>
<body>
<div class="wrap">
  <div class="hero">
    <div class="brand">
      <h1>⚡ 黎明多链监听机器人</h1>
      <p>ETH / BSC / BTC / TRON 地址入账、出账监听看板</p>
    </div>
    <div class="badge"><?=Utils::h($config['copyright'] ?? '@Addliming')?></div>
  </div>
  <div class="grid">
    <div class="card"><div class="num"><?=$stats['addresses']?></div><div class="label">监听地址</div></div>
    <div class="card"><div class="num"><?=$stats['txs']?></div><div class="label">记录交易</div></div>
    <div class="card"><div class="num"><?=$stats['users']?></div><div class="label">Telegram 用户</div></div>
  </div>
  <div class="card">
    <h2>监听地址列表</h2>
    <table>
      <thead><tr><th>ID</th><th>链</th><th>地址</th><th>备注</th><th>Chat ID</th><th>添加时间</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td><?=Utils::h($r['id'])?></td>
          <td><span class="chain"><?=Utils::h($r['chain'])?></span></td>
          <td class="addr"><?=Utils::h(Utils::short($r['address'], 12, 10))?></td>
          <td><?=Utils::h($r['label'])?></td>
          <td><?=Utils::h($r['chat_id'])?></td>
          <td><?=Utils::h($r['created_at'])?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$rows): ?><tr><td colspan="6">暂无监听地址</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="footer">Powered by <?=Utils::h($config['copyright'] ?? '@Addliming')?></div>
</div>
</body>
</html>
