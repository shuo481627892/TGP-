<?php
// 修复数据库中已经添加过的无效监听地址：php repair_invalid_addresses.php
require __DIR__ . '/bootstrap.php';

$rows = $db->activeAddresses();
$invalid = [];
foreach ($rows as $row) {
    $chain = Utils::normalizeChain((string)$row['chain']) ?: (string)$row['chain'];
    $address = trim((string)$row['address']);
    if (!Utils::validateAddress($chain, $address)) {
        $invalid[] = $row;
        $db->deactivateAddress((int)$row['id']);
        echo "DEACTIVATED #{$row['id']} {$chain} {$address}\n";
    }
}

if (!$invalid) {
    echo "No invalid active addresses found.\n";
} else {
    echo "Done. Invalid active addresses deactivated: " . count($invalid) . "\n";
    echo "Please copy the complete correct address and add it again in Telegram.\n";
}
