<?php
class BotController
{
    private DB $db;
    private Telegram $tg;
    private ChainProviders $providers;
    private array $config;

    public function __construct(DB $db, Telegram $tg, ChainProviders $providers, array $config)
    {
        $this->db = $db;
        $this->tg = $tg;
        $this->providers = $providers;
        $this->config = $config;
    }

    public function handleUpdate(array $update): void
    {
        if (isset($update['callback_query'])) {
            $this->handleCallback($update['callback_query']);
            return;
        }
        if (!isset($update['message'])) return;
        $msg = $update['message'];
        $chatId = (string)($msg['chat']['id'] ?? '');
        $from = $msg['from'] ?? [];
        $userId = (string)($from['id'] ?? '');
        $text = trim((string)($msg['text'] ?? ''));
        if ($chatId === '' || $text === '') return;
        $this->db->upsertUser($from, $chatId);

        $state = $this->db->getState($chatId)['state'] ?? '';
        if ($state === 'batch_add' && !str_starts_with($text, '/')) {
            $this->db->setState($chatId, '');
            $this->handleBatchAdd($chatId, $userId, $text);
            return;
        }
        if ($state === 'query_balance' && !str_starts_with($text, '/')) {
            $this->db->setState($chatId, '');
            $this->handleBalanceQuery($chatId, $text);
            return;
        }

        $lower = strtolower($text);
        if ($lower === '/start' || $lower === '/menu') {
            $this->sendMenu($chatId);
            return;
        }
        if (str_starts_with($lower, '/help')) {
            $this->sendHelp($chatId);
            return;
        }
        if (str_starts_with($lower, '/batch')) {
            $this->askBatch($chatId);
            return;
        }
        if (str_starts_with($lower, '/balance') || str_starts_with($lower, '/bal')) {
            $payload = trim(preg_replace('/^\/(balance|bal)\b/i', '', $text));
            if ($payload === '') {
                $this->askBalance($chatId);
            } else {
                $this->handleBalanceQuery($chatId, $payload);
            }
            return;
        }
        if (str_starts_with($lower, '/add')) {
            $payload = trim(substr($text, 4));
            if ($payload === '') {
                $this->tg->sendMessage($chatId, $this->addUsage(), $this->backKeyboard());
                return;
            }
            $this->handleBatchAdd($chatId, $userId, $payload);
            return;
        }
        if (str_starts_with($lower, '/list')) {
            $this->sendList($chatId);
            return;
        }
        if (str_starts_with($lower, '/del')) {
            $payload = trim(substr($text, 4));
            if ($payload === '') {
                $this->tg->sendMessage($chatId, "发送：<code>/del 地址ID</code>\n也可以在地址列表里点删除按钮。", $this->backKeyboard());
                return;
            }
            $ok = $this->deleteByPayload($chatId, $payload);
            $this->tg->sendMessage($chatId, $ok ? "✅ 已删除监听：<code>" . Utils::h($payload) . "</code>" : "❌ 未找到可删除的监听：<code>" . Utils::h($payload) . "</code>", $this->mainKeyboard());
            return;
        }
        if (str_starts_with($lower, '/chain') || str_starts_with($lower, '/chains')) {
            $this->sendChains($chatId);
            return;
        }

        // 用户直接发送地址：自动识别链并查询余额。
        if (Utils::detectAddressFromText($text)) {
            $this->handleBalanceQuery($chatId, $text);
            return;
        }

        $this->tg->sendMessage($chatId, "我没有识别这个指令。你也可以直接发送 ETH/BSC/BTC/TRON 地址，我会自动查询余额。", $this->mainKeyboard());
    }

    private function handleCallback(array $cb): void
    {
        $id = (string)($cb['id'] ?? '');
        $data = (string)($cb['data'] ?? '');
        $msg = $cb['message'] ?? [];
        $chatId = (string)($msg['chat']['id'] ?? '');
        $messageId = (int)($msg['message_id'] ?? 0);
        $from = $cb['from'] ?? [];
        $this->db->upsertUser($from, $chatId);

        try { $this->tg->answerCallback($id); } catch (Throwable $e) {}

        if ($data === 'menu') {
            $this->editOrSend($chatId, $messageId, $this->menuText(), $this->mainKeyboard());
            return;
        }
        if ($data === 'query_balance') {
            $this->db->setState($chatId, 'query_balance');
            $this->editOrSend($chatId, $messageId, $this->balanceUsage(), $this->backKeyboard());
            return;
        }
        if ($data === 'add_batch') {
            $this->db->setState($chatId, 'batch_add');
            $this->editOrSend($chatId, $messageId, $this->addUsage(), $this->backKeyboard());
            return;
        }
        if ($data === 'list') {
            $this->sendList($chatId, $messageId);
            return;
        }
        if ($data === 'chains') {
            $this->editOrSend($chatId, $messageId, $this->chainsText(), $this->backKeyboard());
            return;
        }
        if ($data === 'help') {
            $this->editOrSend($chatId, $messageId, $this->helpText(), $this->backKeyboard());
            return;
        }
        if (str_starts_with($data, 'del:')) {
            $addrId = (int)substr($data, 4);
            $ok = $this->db->deactivateAddress($addrId, $chatId);
            $this->editOrSend($chatId, $messageId, $ok ? "✅ 已删除监听 ID：<code>{$addrId}</code>" : "❌ 删除失败或无权限。", $this->mainKeyboard());
            return;
        }
    }

    private function editOrSend(string $chatId, int $messageId, string $text, array $keyboard): void
    {
        try {
            if ($messageId > 0) $this->tg->editMessageText($chatId, $messageId, $text, $keyboard);
            else $this->tg->sendMessage($chatId, $text, $keyboard);
        } catch (Throwable $e) {
            $this->tg->sendMessage($chatId, $text, $keyboard);
        }
    }

    private function sendMenu(string $chatId): void
    {
        $this->tg->sendMessage($chatId, $this->menuText(), $this->mainKeyboard());
    }

    private function menuText(): string
    {
        $stats = $this->db->stats();
        return "<b>⚡ 黎明多链地址监听机器人</b>\n\n" .
            "支持 ETH / BTC / TRON(TRX、TRC20) / BSC(兼容你说的 BCS)。\n" .
            "可以批量添加地址，出现入账或出账时自动推送。\n" .
            "直接发送任意支持链地址，可自动识别并查询余额。\n\n" .
            "📌 当前监听：<b>{$stats['addresses']}</b> 个地址\n" .
            "🧾 已记录交易：<b>{$stats['txs']}</b> 条\n\n" .
            "请选择功能：\n\n" . Utils::h($this->config['copyright'] ?? '@Addliming');
    }

    private function mainKeyboard(): array
    {
        return [
            [
                ['text' => '🔎 查询余额', 'callback_data' => 'query_balance'],
                ['text' => '➕ 批量添加监听', 'callback_data' => 'add_batch'],
            ],
            [
                ['text' => '📋 地址列表', 'callback_data' => 'list'],
                ['text' => '⛓ 支持链说明', 'callback_data' => 'chains'],
            ],
            [
                ['text' => '📖 使用帮助', 'callback_data' => 'help'],
            ],
        ];
    }

    private function backKeyboard(): array
    {
        return [[['text' => '⬅️ 返回主菜单', 'callback_data' => 'menu']]];
    }

    private function balanceUsage(): string
    {
        return "<b>🔎 查询地址余额</b>\n\n" .
            "请直接发送地址，机器人会自动识别：\n" .
            "<code>0x0000000000000000000000000000000000000000</code>\n" .
            "<code>Txxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx</code>\n" .
            "<code>bc1xxxxxxxxxxxxxxxxxxxxxxxxxxxx</code>\n\n" .
            "说明：0x 地址无法仅凭地址区分 ETH 或 BSC，所以系统会同时查询 ETH 与 BSC。\n\n" . Utils::h($this->config['copyright'] ?? '@Addliming');
    }

    private function askBalance(string $chatId): void
    {
        $this->db->setState($chatId, 'query_balance');
        $this->tg->sendMessage($chatId, $this->balanceUsage(), $this->backKeyboard());
    }

    private function handleBalanceQuery(string $chatId, string $text): void
    {
        $detected = Utils::detectAddressFromText($text);
        if (!$detected) {
            $this->tg->sendMessage($chatId, "❌ 没有识别到支持的链上地址。\n\n支持 ETH/BSC 0x 地址、BTC 地址、TRON T 地址。", $this->mainKeyboard());
            return;
        }

        $address = $detected['address'];
        $chains = $detected['chains'];

        // 如果用户写了明确链名，如 /balance BSC 0x...，则按指定链查询；直接发 0x 地址则 ETH+BSC 同查。
        $tokens = preg_split('/\s+|,|\|/', trim($text));
        $specified = Utils::normalizeChain((string)($tokens[0] ?? ''));
        if ($specified && Utils::validateAddress($specified, $address)) {
            $chains = [$specified];
        }

        $reply = "<b>🔎 地址余额查询结果</b>\n\n" .
            "👛 地址：<code>" . Utils::h($address) . "</code>\n";

        if (($detected['type'] ?? '') === 'EVM' && count($chains) > 1) {
            $reply .= "🧠 识别：<b>EVM 地址</b>，ETH 与 BSC/BCS 地址格式相同，已同时查询。\n\n";
        } else {
            $reply .= "🧠 识别：<b>" . Utils::h(Utils::chainTitle($chains[0])) . "</b>\n\n";
        }

        foreach ($chains as $chain) {
            if (!Utils::validateAddress($chain, $address)) {
                $reply .= "<b>" . Utils::h(Utils::chainTitle($chain)) . "</b>\n❌ 地址格式不合法\n\n";
                continue;
            }
            try {
                $balances = $this->providers->getBalancesForAddress($chain, $address);
                $reply .= "<b>⛓ " . Utils::h(Utils::chainTitle($chain)) . "</b>\n";
                foreach ($balances as $bal) {
                    $ok = $bal['ok'] ?? true;
                    if ($ok) {
                        $reply .= "💼 " . Utils::h($bal['symbol']) . "：<b>" . Utils::h((string)$bal['balance']) . "</b>\n";
                    } else {
                        $reply .= "⚠️ " . Utils::h($bal['symbol']) . "：" . Utils::h((string)$bal['balance']) . "\n";
                    }
                }
                $reply .= "\n";
            } catch (Throwable $e) {
                $reply .= "<b>⛓ " . Utils::h(Utils::chainTitle($chain)) . "</b>\n" .
                    "⚠️ 查询失败：" . Utils::h($e->getMessage()) . "\n\n";
            }
        }

        $reply .= "需要监听这个地址时，请点“批量添加监听”或发送 <code>/add 链 地址 备注</code>。\n\n" . Utils::h($this->config['copyright'] ?? '@Addliming');
        $this->tg->sendMessage($chatId, $reply, $this->mainKeyboard());
    }

    private function addUsage(): string
    {
        return "<b>➕ 批量添加监听地址</b>\n\n" .
            "请直接发送多行文本，每行一个地址。支持写链名，也支持省略链名自动识别：\n" .
            "<code>ETH 0x0000000000000000000000000000000000000000 备注</code>\n" .
            "<code>BSC 0x0000000000000000000000000000000000000000 备注</code>\n" .
            "<code>BTC bc1xxxxxxxxxxxxxxxxxxxxxxxxxxxx 备注</code>\n" .
            "<code>TRON Txxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx 备注</code>\n" .
            "<code>Txxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx TRON钱包</code>\n\n" .
            "也支持逗号格式：\n" .
            "<code>TRC20,Txxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx,USDT收款</code>\n\n" .
            "说明：BCS 会自动按 BSC 处理；TRX/TRC20 都按 TRON 处理。省略链名的 0x 地址会同时添加 ETH 和 BSC。\n\n" . Utils::h($this->config['copyright'] ?? '@Addliming');
    }

    private function askBatch(string $chatId): void
    {
        $this->db->setState($chatId, 'batch_add');
        $this->tg->sendMessage($chatId, $this->addUsage(), $this->backKeyboard());
    }

    private function handleBatchAdd(string $chatId, string $userId, string $text): void
    {
        $lines = preg_split('/\r\n|\r|\n/', trim($text));
        $ok = [];
        $fail = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') continue;
            $parsedRows = $this->parseAddressLine($line);
            if (!$parsedRows) {
                $fail[] = "格式错误：" . Utils::h($line);
                continue;
            }
            foreach ($parsedRows as $parsed) {
                [$chain, $address, $label] = $parsed;
                if (!Utils::validateAddress($chain, $address)) {
                    $fail[] = "地址不合法：" . Utils::h($chain . ' ' . $address);
                    continue;
                }
                try {
                    $addrId = $this->db->addAddress($chain, $address, $label, $chatId, $userId);
                    $this->seedRecentTransactions($chain, $address);
                    $ok[] = "✅ #{$addrId} " . Utils::h($chain) . " " . Utils::h(Utils::short($address)) . ($label ? " - " . Utils::h($label) : '');
                } catch (Throwable $e) {
                    $fail[] = "添加失败：" . Utils::h($chain . ' ' . $address) . "｜" . Utils::h($e->getMessage());
                }
            }
        }
        $msg = "<b>批量添加完成</b>\n\n";
        if ($ok) $msg .= "<b>成功：</b>\n" . implode("\n", array_slice($ok, 0, 40)) . "\n\n";
        if ($fail) $msg .= "<b>失败：</b>\n" . implode("\n", array_slice($fail, 0, 20)) . "\n\n";
        if (!$ok && !$fail) $msg .= "没有检测到有效内容。\n\n";
        $msg .= "为了避免添加后立刻推送历史交易，系统已把最近交易作为基线记录。\n\n" . Utils::h($this->config['copyright'] ?? '@Addliming');
        $this->tg->sendMessage($chatId, $msg, $this->mainKeyboard());
    }

    /** 返回多条 [chain,address,label]；省略链名的 0x 地址会返回 ETH+BSC 两条。 */
    private function parseAddressLine(string $line): array
    {
        $parts = [];
        if (str_contains($line, ',')) {
            $parts = array_map('trim', explode(',', $line, 3));
        } elseif (str_contains($line, '|')) {
            $parts = array_map('trim', explode('|', $line, 3));
        } else {
            $parts = preg_split('/\s+/', $line, 3);
        }

        if (count($parts) >= 2) {
            $chain = Utils::normalizeChain($parts[0]);
            if ($chain) {
                $address = trim($parts[1]);
                $label = trim($parts[2] ?? '');
                return [[$chain, $address, $label]];
            }
        }

        $detected = Utils::detectAddressFromText($line);
        if (!$detected) return [];
        $address = $detected['address'];
        $label = $this->labelAfterAddress($line, $address);
        $rows = [];
        foreach ($detected['chains'] as $chain) {
            $rows[] = [$chain, $address, $label];
        }
        return $rows;
    }

    private function labelAfterAddress(string $line, string $address): string
    {
        $label = str_replace($address, '', $line);
        $label = trim($label);
        $label = trim($label, " \t\n\r\0\x0B,|，：:");
        return $label;
    }

    private function seedRecentTransactions(string $chain, string $address): void
    {
        try {
            $txs = $this->providers->fetchTransactions($chain, $address, min(5, (int)($this->config['fetch_limit'] ?? 10)));
            foreach ($txs as $tx) $this->db->insertTx($tx, 0);
        } catch (Throwable $e) {
            $this->db->log('WARN', 'seed failed ' . $chain . ' ' . $address . ': ' . $e->getMessage());
        }
    }

    private function sendList(string $chatId, int $messageId = 0): void
    {
        $rows = $this->db->listAddresses($chatId, true);
        if (!$rows) {
            $this->editOrSend($chatId, $messageId, "暂无监听地址。点击“批量添加监听”开始添加。", $this->mainKeyboard());
            return;
        }
        $text = "<b>📋 当前监听地址</b>\n\n";
        $keyboard = [];
        foreach (array_slice($rows, 0, 50) as $row) {
            $label = $row['label'] ? '｜' . $row['label'] : '';
            $text .= "#{$row['id']} <b>" . Utils::h($row['chain']) . "</b> " . Utils::h(Utils::short($row['address'], 10, 8)) . Utils::h($label) . "\n";
            $keyboard[] = [[
                'text' => '🗑 删除 #' . $row['id'] . ' ' . $row['chain'] . ' ' . Utils::short($row['address'], 6, 4),
                'callback_data' => 'del:' . $row['id']
            ]];
        }
        $keyboard[] = [['text' => '⬅️ 返回主菜单', 'callback_data' => 'menu']];
        $text .= "\n提示：点击下方按钮可删除对应地址。\n\n" . Utils::h($this->config['copyright'] ?? '@Addliming');
        $this->editOrSend($chatId, $messageId, $text, $keyboard);
    }

    private function deleteByPayload(string $chatId, string $payload): bool
    {
        if (ctype_digit($payload)) {
            return $this->db->deactivateAddress((int)$payload, $chatId);
        }
        return false;
    }

    private function sendChains(string $chatId): void
    {
        $this->tg->sendMessage($chatId, $this->chainsText(), $this->backKeyboard());
    }

    private function chainsText(): string
    {
        return "<b>⛓ 支持链说明</b>\n\n" .
            "✅ ETH：ETH 原生转账 + ERC20 代币，余额查询默认显示 ETH / USDT / USDC\n" .
            "✅ BSC/BCS：BNB 原生转账 + BEP20 代币，余额查询默认显示 BNB / USDT / USDC\n" .
            "✅ BTC：BTC 入账/出账，余额查询显示 BTC\n" .
            "✅ TRON：TRX 原生转账 + TRC20 代币，余额查询默认显示 TRX / USDT-TRC20\n\n" .
            "提醒说明：监听地址发生转账时，会显示转入/转出数量，并实时查询该币种当前剩余余额。\n\n" .
            "接口说明：ETH/BSC 使用 Etherscan API V2；TRON 使用 TronGrid；BTC 使用 Blockstream Esplora。\n\n" . Utils::h($this->config['copyright'] ?? '@Addliming');
    }

    private function sendHelp(string $chatId): void
    {
        $this->tg->sendMessage($chatId, $this->helpText(), $this->backKeyboard());
    }

    private function helpText(): string
    {
        return "<b>📖 使用帮助</b>\n\n" .
            "<code>/start</code> 打开菜单\n" .
            "<code>/balance 地址</code> 查询余额；直接发地址也可以查询\n" .
            "<code>/batch</code> 批量添加监听地址\n" .
            "<code>/add ETH 0x... 备注</code> 添加单个或多行地址\n" .
            "<code>/list</code> 查看地址列表\n" .
            "<code>/del 12</code> 删除 ID 为 12 的监听\n" .
            "<code>/chains</code> 查看支持链\n\n" .
            "批量添加时可省略链名自动识别；0x 地址会同时按 ETH+BSC 添加。\n" .
            "建议用 supervisor 或 systemd 同时守护 bot.php 和 monitor.php。\n\n" . Utils::h($this->config['copyright'] ?? '@Addliming');
    }
}
