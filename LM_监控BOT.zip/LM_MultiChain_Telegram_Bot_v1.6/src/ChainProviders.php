<?php
class ChainProviders
{
    private array $config;

    public function __construct(array $config)
    {
        $this->config = $config;
    }

    public function fetchTransactions(string $chain, string $address, int $limit = 10): array
    {
        $chain = Utils::normalizeChain($chain) ?: $chain;
        $address = trim($address);
        if (!Utils::validateAddress($chain, $address)) {
            throw new RuntimeException(Utils::chainTitle($chain) . ' 地址格式或校验位错误：' . $address);
        }
        if ($chain === 'ETH') return $this->fetchEvm('ETH', '1', $address, $limit);
        if ($chain === 'BSC') return $this->fetchEvm('BSC', '56', $address, $limit);
        if ($chain === 'BTC') return $this->fetchBtc($address, $limit);
        if ($chain === 'TRON') return $this->fetchTron($address, $limit);
        return [];
    }

    /** 查询一个地址在指定链上的常用余额。 */
    public function getBalancesForAddress(string $chain, string $address): array
    {
        $chain = Utils::normalizeChain($chain) ?: $chain;
        $address = trim($address);
        if (!Utils::validateAddress($chain, $address)) {
            throw new RuntimeException(Utils::chainTitle($chain) . ' 地址格式或校验位错误：' . $address);
        }
        if ($chain === 'ETH') return $this->getEvmBalances('ETH', '1', $address);
        if ($chain === 'BSC') return $this->getEvmBalances('BSC', '56', $address);
        if ($chain === 'BTC') return [$this->getBtcBalance($address)];
        if ($chain === 'TRON') return $this->getTronBalances($address);
        return [];
    }

    /** 监听通知时，按本次转账币种查询当前剩余余额。 */
    public function getPostTxBalance(array $tx): ?array
    {
        $chain = Utils::normalizeChain((string)($tx['chain'] ?? '')) ?: (string)($tx['chain'] ?? '');
        $address = trim((string)($tx['address'] ?? ''));
        if (!Utils::validateAddress($chain, $address)) {
            throw new RuntimeException(Utils::chainTitle($chain) . ' 地址格式或校验位错误：' . $address);
        }
        $symbol = (string)($tx['symbol'] ?? Utils::nativeSymbol($chain));
        $raw = $tx['raw'] ?? [];

        if ($chain === 'ETH' || $chain === 'BSC') {
            $chainId = $chain === 'ETH' ? '1' : '56';
            $native = Utils::nativeSymbol($chain);
            $contract = (string)($raw['contractAddress'] ?? '');
            if ($contract !== '' && strtoupper($symbol) !== $native) {
                $decimals = (int)($raw['tokenDecimal'] ?? 18);
                return $this->getEvmTokenBalance($chain, $chainId, $address, $contract, $symbol ?: 'TOKEN', $decimals);
            }
            if (strtoupper($symbol) !== $native) {
                $token = $this->findCommonTokenBySymbol($chain, $symbol);
                if ($token) {
                    return $this->getEvmTokenBalance($chain, $chainId, $address, $token['contract'], $token['symbol'], (int)$token['decimals']);
                }
            }
            return $this->getEvmNativeBalance($chain, $chainId, $address);
        }

        if ($chain === 'BTC') {
            return $this->getBtcBalance($address);
        }

        if ($chain === 'TRON') {
            $contract = (string)(
                $raw['token_info']['address']
                ?? $raw['token_info']['token_id']
                ?? $raw['token_info']['contract_address']
                ?? $raw['contract_address']
                ?? ''
            );
            if ($contract !== '' && strtoupper($symbol) !== 'TRX') {
                $decimals = (int)($raw['token_info']['decimals'] ?? $raw['token_info']['token_decimal'] ?? 6);
                return $this->getTronTokenBalance($address, $contract, $symbol ?: 'TRC20', $decimals);
            }
            if (strtoupper($symbol) !== 'TRX') {
                $token = $this->findCommonTokenBySymbol('TRON', $symbol);
                if ($token) {
                    return $this->getTronTokenBalance($address, $token['contract'], $token['symbol'], (int)$token['decimals']);
                }
            }
            return $this->getTrxBalance($address);
        }

        return null;
    }

    // ---------------- EVM：ETH / BSC ----------------

    private function fetchEvm(string $chain, string $chainId, string $address, int $limit): array
    {
        $apiKey = $this->etherscanApiKey();
        $base = rtrim($this->config['etherscan_v2_base'] ?? 'https://api.etherscan.io/v2/api', '/');
        $out = [];

        $normal = $this->etherscanCall($base, [
            'chainid' => $chainId,
            'module' => 'account',
            'action' => 'txlist',
            'address' => $address,
            'page' => 1,
            'offset' => $limit,
            'sort' => 'desc',
            'apikey' => $apiKey,
        ]);
        foreach ($normal as $row) {
            if (($row['isError'] ?? '0') === '1') continue;
            $from = strtolower($row['from'] ?? '');
            $to = strtolower($row['to'] ?? '');
            $watch = strtolower($address);
            if ($from !== $watch && $to !== $watch) continue;
            $direction = $to === $watch ? 'IN' : 'OUT';
            $amount = Utils::decimalAmount((string)($row['value'] ?? '0'), 18);
            if ($amount === '0') continue;
            $tx = [
                'chain' => $chain,
                'address' => $address,
                'txid' => $row['hash'] ?? '',
                'event_key' => 'native:' . ($row['hash'] ?? ''),
                'direction' => $direction,
                'symbol' => Utils::nativeSymbol($chain),
                'amount' => $amount,
                'from_addr' => $row['from'] ?? '',
                'to_addr' => $row['to'] ?? '',
                'block_time' => Utils::txTime((int)($row['timeStamp'] ?? 0)),
                'timestamp' => (int)($row['timeStamp'] ?? 0),
                'raw' => $row,
            ];
            $tx['unique_key'] = Utils::uniqueKey($tx);
            $out[] = $tx;
        }

        $tokens = $this->etherscanCall($base, [
            'chainid' => $chainId,
            'module' => 'account',
            'action' => 'tokentx',
            'address' => $address,
            'page' => 1,
            'offset' => $limit,
            'sort' => 'desc',
            'apikey' => $apiKey,
        ]);
        foreach ($tokens as $row) {
            $from = strtolower($row['from'] ?? '');
            $to = strtolower($row['to'] ?? '');
            $watch = strtolower($address);
            if ($from !== $watch && $to !== $watch) continue;
            $direction = $to === $watch ? 'IN' : 'OUT';
            $decimals = (int)($row['tokenDecimal'] ?? 18);
            $amount = Utils::decimalAmount((string)($row['value'] ?? '0'), $decimals);
            if ($amount === '0') continue;
            $tx = [
                'chain' => $chain,
                'address' => $address,
                'txid' => $row['hash'] ?? '',
                'event_key' => 'erc20:' . ($row['hash'] ?? '') . ':' . ($row['contractAddress'] ?? '') . ':' . ($row['logIndex'] ?? '') . ':' . ($row['value'] ?? ''),
                'direction' => $direction,
                'symbol' => $row['tokenSymbol'] ?? 'TOKEN',
                'amount' => $amount,
                'from_addr' => $row['from'] ?? '',
                'to_addr' => $row['to'] ?? '',
                'block_time' => Utils::txTime((int)($row['timeStamp'] ?? 0)),
                'timestamp' => (int)($row['timeStamp'] ?? 0),
                'raw' => $row,
            ];
            $tx['unique_key'] = Utils::uniqueKey($tx);
            $out[] = $tx;
        }

        usort($out, fn($a, $b) => ($b['timestamp'] ?? 0) <=> ($a['timestamp'] ?? 0));
        return array_slice($out, 0, $limit * 2);
    }

    private function getEvmBalances(string $chain, string $chainId, string $address): array
    {
        $balances = [];
        $balances[] = $this->getEvmNativeBalance($chain, $chainId, $address);

        foreach ($this->commonTokens($chain) as $token) {
            try {
                $balances[] = $this->getEvmTokenBalance($chain, $chainId, $address, $token['contract'], $token['symbol'], (int)$token['decimals']);
            } catch (Throwable $e) {
                $balances[] = [
                    'chain' => $chain,
                    'symbol' => $token['symbol'],
                    'balance' => '查询失败：' . $e->getMessage(),
                    'contract' => $token['contract'],
                    'ok' => false,
                ];
            }
        }
        return $balances;
    }

    private function getEvmNativeBalance(string $chain, string $chainId, string $address): array
    {
        $result = $this->etherscanRaw([
            'chainid' => $chainId,
            'module' => 'account',
            'action' => 'balance',
            'address' => $address,
            'tag' => 'latest',
            'apikey' => $this->etherscanApiKey(),
        ]);
        return [
            'chain' => $chain,
            'symbol' => Utils::nativeSymbol($chain),
            'balance' => Utils::decimalAmount((string)$result, 18),
            'contract' => '',
            'ok' => true,
        ];
    }

    private function getEvmTokenBalance(string $chain, string $chainId, string $address, string $contract, string $symbol, int $decimals): array
    {
        $result = $this->etherscanRaw([
            'chainid' => $chainId,
            'module' => 'account',
            'action' => 'tokenbalance',
            'contractaddress' => $contract,
            'address' => $address,
            'tag' => 'latest',
            'apikey' => $this->etherscanApiKey(),
        ]);
        return [
            'chain' => $chain,
            'symbol' => $symbol,
            'balance' => Utils::decimalAmount((string)$result, $decimals),
            'contract' => $contract,
            'ok' => true,
        ];
    }

    private function etherscanApiKey(): string
    {
        $apiKey = trim((string)($this->config['etherscan_api_key'] ?? ''));
        if ($apiKey === '' || str_contains($apiKey, 'PUT_')) {
            throw new RuntimeException('ETH/BSC 查询需要在 config.php 填写 etherscan_api_key');
        }
        return $apiKey;
    }

    private function etherscanRaw(array $params)
    {
        $base = rtrim($this->config['etherscan_v2_base'] ?? 'https://api.etherscan.io/v2/api', '/');
        $url = $base . '?' . http_build_query($params);
        $json = Utils::httpGetJson($url, [], 20, (string)($this->config['proxy'] ?? ''));
        $result = $json['result'] ?? null;
        if ($result === null) {
            throw new RuntimeException('Etherscan 无 result 返回');
        }
        if (($json['status'] ?? '1') === '0') {
            $msg = strtolower((string)$result . ' ' . (string)($json['message'] ?? ''));
            if (str_contains($msg, 'no transactions')) return [];
            if (is_string($result) && preg_match('/^[0-9]+$/', $result)) return $result;
            throw new RuntimeException('Etherscan 返回错误：' . (is_string($result) ? $result : json_encode($result, JSON_UNESCAPED_UNICODE)));
        }
        return $result;
    }

    private function etherscanCall(string $base, array $params): array
    {
        $url = $base . '?' . http_build_query($params);
        $json = Utils::httpGetJson($url, [], 20, (string)($this->config['proxy'] ?? ''));
        $result = $json['result'] ?? [];
        if (is_string($result)) {
            $msg = strtolower($result . ' ' . ($json['message'] ?? ''));
            if (str_contains($msg, 'no transactions')) return [];
            throw new RuntimeException('Etherscan 返回错误：' . $result);
        }
        if (!is_array($result)) return [];
        return $result;
    }

    // ---------------- TRON：TRX / TRC20 ----------------

    private function fetchTron(string $address, int $limit): array
    {
        $base = rtrim($this->config['trongrid_base'] ?? 'https://api.trongrid.io', '/');
        $headers = $this->tronHeaders();
        $proxy = (string)($this->config['proxy'] ?? '');
        $out = [];

        // TRC20：包含 USDT-TRC20 等代币转账
        $url = $base . '/v1/accounts/' . rawurlencode($address) . '/transactions/trc20?' . http_build_query([
            'only_confirmed' => 'true',
            'limit' => $limit,
            'order_by' => 'block_timestamp,desc',
        ]);
        $json = Utils::httpGetJson($url, $headers, 20, $proxy);
        foreach (($json['data'] ?? []) as $row) {
            $from = $row['from'] ?? '';
            $to = $row['to'] ?? '';
            if ($from !== $address && $to !== $address) continue;
            $decimals = (int)($row['token_info']['decimals'] ?? $row['token_info']['token_decimal'] ?? 6);
            $symbol = $row['token_info']['symbol'] ?? $row['token_info']['token_abbr'] ?? 'TRC20';
            $direction = $to === $address ? 'IN' : 'OUT';
            $amount = Utils::decimalAmount((string)($row['value'] ?? '0'), $decimals);
            if ($amount === '0') continue;
            $timestamp = (int)floor((int)($row['block_timestamp'] ?? 0) / 1000);
            $tx = [
                'chain' => 'TRON',
                'address' => $address,
                'txid' => $row['transaction_id'] ?? '',
                'event_key' => 'trc20:' . ($row['transaction_id'] ?? '') . ':' . ($row['token_info']['address'] ?? $row['token_info']['token_id'] ?? '') . ':' . ($row['from'] ?? '') . ':' . ($row['to'] ?? '') . ':' . ($row['value'] ?? ''),
                'direction' => $direction,
                'symbol' => $symbol,
                'amount' => $amount,
                'from_addr' => $from,
                'to_addr' => $to,
                'block_time' => Utils::txTime($timestamp),
                'timestamp' => $timestamp,
                'raw' => $row,
            ];
            $tx['unique_key'] = Utils::uniqueKey($tx);
            $out[] = $tx;
        }

        // TRX 原生转账
        $url = $base . '/v1/accounts/' . rawurlencode($address) . '/transactions?' . http_build_query([
            'only_confirmed' => 'true',
            'limit' => $limit,
            'order_by' => 'block_timestamp,desc',
        ]);
        $json = Utils::httpGetJson($url, $headers, 20, $proxy);
        foreach (($json['data'] ?? []) as $row) {
            $contract = $row['raw_data']['contract'][0] ?? null;
            if (!$contract || (($contract['type'] ?? '') !== 'TransferContract')) continue;
            $value = $contract['parameter']['value'] ?? [];
            $from = Utils::tronHexToBase58($value['owner_address'] ?? '');
            $to = Utils::tronHexToBase58($value['to_address'] ?? '');
            if ($from !== $address && $to !== $address) continue;
            $direction = $to === $address ? 'IN' : 'OUT';
            $amount = Utils::decimalAmount((string)($value['amount'] ?? '0'), 6);
            if ($amount === '0') continue;
            $timestamp = (int)floor((int)($row['block_timestamp'] ?? 0) / 1000);
            $tx = [
                'chain' => 'TRON',
                'address' => $address,
                'txid' => $row['txID'] ?? '',
                'event_key' => 'trx:' . ($row['txID'] ?? '') . ':' . ($value['amount'] ?? ''),
                'direction' => $direction,
                'symbol' => 'TRX',
                'amount' => $amount,
                'from_addr' => $from,
                'to_addr' => $to,
                'block_time' => Utils::txTime($timestamp),
                'timestamp' => $timestamp,
                'raw' => $row,
            ];
            $tx['unique_key'] = Utils::uniqueKey($tx);
            $out[] = $tx;
        }

        usort($out, fn($a, $b) => ($b['timestamp'] ?? 0) <=> ($a['timestamp'] ?? 0));
        return array_slice($out, 0, $limit * 2);
    }

    private function getTronBalances(string $address): array
    {
        $balances = [$this->getTrxBalance($address)];
        foreach ($this->commonTokens('TRON') as $token) {
            try {
                $balances[] = $this->getTronTokenBalance($address, $token['contract'], $token['symbol'], (int)$token['decimals']);
            } catch (Throwable $e) {
                $balances[] = [
                    'chain' => 'TRON',
                    'symbol' => $token['symbol'],
                    'balance' => '查询失败：' . $e->getMessage(),
                    'contract' => $token['contract'],
                    'ok' => false,
                ];
            }
        }
        return $balances;
    }

    private function getTrxBalance(string $address): array
    {
        $base = rtrim($this->config['trongrid_base'] ?? 'https://api.trongrid.io', '/');
        $json = Utils::httpGetJson($base . '/v1/accounts/' . rawurlencode($address), $this->tronHeaders(), 20, (string)($this->config['proxy'] ?? ''));
        $row = $json['data'][0] ?? [];
        $sun = (string)($row['balance'] ?? '0');
        return [
            'chain' => 'TRON',
            'symbol' => 'TRX',
            'balance' => Utils::decimalAmount($sun, 6),
            'contract' => '',
            'ok' => true,
        ];
    }

    private function getTronTokenBalance(string $address, string $contract, string $symbol, int $decimals): array
    {
        $base = rtrim($this->config['trongrid_base'] ?? 'https://api.trongrid.io', '/');
        $ownerHex = Utils::tronBase58ToHex($address);
        $contractHex = Utils::tronContractToHex($contract);
        if (!$ownerHex || !$contractHex) {
            throw new RuntimeException('TRON 地址或合约地址格式错误');
        }
        $parameter = str_pad(substr($ownerHex, 2), 64, '0', STR_PAD_LEFT);
        $json = Utils::httpPostJson($base . '/wallet/triggerconstantcontract', [
            'owner_address' => $ownerHex,
            'contract_address' => $contractHex,
            'function_selector' => 'balanceOf(address)',
            'parameter' => $parameter,
            'visible' => false,
        ], $this->tronHeaders(), 20, (string)($this->config['proxy'] ?? ''));

        $hex = (string)($json['constant_result'][0] ?? '0');
        $integer = Utils::hexToDec($hex);
        return [
            'chain' => 'TRON',
            'symbol' => $symbol,
            'balance' => Utils::decimalAmount($integer, $decimals),
            'contract' => $contract,
            'ok' => true,
        ];
    }

    private function tronHeaders(): array
    {
        $headers = [];
        $key = trim((string)($this->config['trongrid_api_key'] ?? ''));
        if ($key !== '') $headers['TRON-PRO-API-KEY'] = $key;
        return $headers;
    }

    // ---------------- BTC ----------------

    private function fetchBtc(string $address, int $limit): array
    {
        $base = rtrim($this->config['blockstream_base'] ?? 'https://blockstream.info/api', '/');
        $proxy = (string)($this->config['proxy'] ?? '');
        $rows = [];
        try {
            $rows = Utils::httpGetJson($base . '/address/' . rawurlencode($address) . '/txs', [], 20, $proxy);
        } catch (Throwable $e) {
            $rows = [];
        }
        try {
            $mempool = Utils::httpGetJson($base . '/address/' . rawurlencode($address) . '/txs/mempool', [], 20, $proxy);
            if (is_array($mempool)) $rows = array_merge($mempool, $rows);
        } catch (Throwable $e) {}

        $out = [];
        foreach (array_slice($rows, 0, $limit) as $row) {
            $received = 0;
            $sent = 0;
            foreach (($row['vout'] ?? []) as $vout) {
                if (($vout['scriptpubkey_address'] ?? '') === $address) {
                    $received += (int)($vout['value'] ?? 0);
                }
            }
            foreach (($row['vin'] ?? []) as $vin) {
                $prev = $vin['prevout'] ?? [];
                if (($prev['scriptpubkey_address'] ?? '') === $address) {
                    $sent += (int)($prev['value'] ?? 0);
                }
            }
            $net = $received - $sent;
            if ($net === 0) continue;
            $direction = $net > 0 ? 'IN' : 'OUT';
            $amountSats = abs($net);
            $timestamp = (int)($row['status']['block_time'] ?? time());
            $peer = $direction === 'IN' ? $this->firstPeerFromInputs($row, $address) : $this->firstPeerFromOutputs($row, $address);
            $tx = [
                'chain' => 'BTC',
                'address' => $address,
                'txid' => $row['txid'] ?? '',
                'event_key' => 'btc:' . ($row['txid'] ?? '') . ':' . $net,
                'direction' => $direction,
                'symbol' => 'BTC',
                'amount' => Utils::btcAmount($amountSats),
                'from_addr' => $direction === 'IN' ? $peer : $address,
                'to_addr' => $direction === 'IN' ? $address : $peer,
                'block_time' => Utils::txTime($timestamp),
                'timestamp' => $timestamp,
                'raw' => $row,
            ];
            $tx['unique_key'] = Utils::uniqueKey($tx);
            $out[] = $tx;
        }
        usort($out, fn($a, $b) => ($b['timestamp'] ?? 0) <=> ($a['timestamp'] ?? 0));
        return $out;
    }

    private function getBtcBalance(string $address): array
    {
        $base = rtrim($this->config['blockstream_base'] ?? 'https://blockstream.info/api', '/');
        $json = Utils::httpGetJson($base . '/address/' . rawurlencode($address), [], 20, (string)($this->config['proxy'] ?? ''));
        $chain = $json['chain_stats'] ?? [];
        $mem = $json['mempool_stats'] ?? [];
        $funded = (int)($chain['funded_txo_sum'] ?? 0) + (int)($mem['funded_txo_sum'] ?? 0);
        $spent = (int)($chain['spent_txo_sum'] ?? 0) + (int)($mem['spent_txo_sum'] ?? 0);
        $balance = max(0, $funded - $spent);
        return [
            'chain' => 'BTC',
            'symbol' => 'BTC',
            'balance' => Utils::btcAmount($balance),
            'contract' => '',
            'ok' => true,
        ];
    }

    private function firstPeerFromInputs(array $row, string $watch): string
    {
        foreach (($row['vin'] ?? []) as $vin) {
            $addr = $vin['prevout']['scriptpubkey_address'] ?? '';
            if ($addr && $addr !== $watch) return $addr;
        }
        return '';
    }

    private function firstPeerFromOutputs(array $row, string $watch): string
    {
        foreach (($row['vout'] ?? []) as $vout) {
            $addr = $vout['scriptpubkey_address'] ?? '';
            if ($addr && $addr !== $watch) return $addr;
        }
        return '';
    }

    private function commonTokens(string $chain): array
    {
        $defaults = [
            'ETH' => [
                ['symbol' => 'USDT', 'contract' => '0xdAC17F958D2ee523a2206206994597C13D831ec7', 'decimals' => 6],
                ['symbol' => 'USDC', 'contract' => '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606EB48', 'decimals' => 6],
            ],
            'BSC' => [
                ['symbol' => 'USDT', 'contract' => '0x55d398326f99059fF775485246999027B3197955', 'decimals' => 18],
                ['symbol' => 'USDC', 'contract' => '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d', 'decimals' => 18],
            ],
            'TRON' => [
                ['symbol' => 'USDT', 'contract' => 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t', 'decimals' => 6],
            ],
        ];
        $custom = $this->config['common_tokens'][$chain] ?? [];
        if (!is_array($custom)) $custom = [];
        return array_values(array_merge($defaults[$chain] ?? [], $custom));
    }

    private function findCommonTokenBySymbol(string $chain, string $symbol): ?array
    {
        $symbol = strtoupper(trim($symbol));
        if ($symbol === '') return null;
        foreach ($this->commonTokens($chain) as $token) {
            if (strtoupper((string)($token['symbol'] ?? '')) === $symbol) {
                return $token;
            }
        }
        return null;
    }
}
