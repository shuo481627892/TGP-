<?php
class Telegram
{
    private string $token;
    private string $proxy;
    private int $connectTimeout;
    private int $requestTimeout;
    private bool $forceIpv4;

    public function __construct(string $token, string $proxy = '', array $options = [])
    {
        $this->token = $token;
        $this->proxy = $proxy;
        $this->connectTimeout = max(3, (int)($options['telegram_connect_timeout'] ?? 15));
        // Telegram getUpdates 长轮询会被服务器挂起一段时间，curl 超时时间必须大于 long polling timeout。
        $this->requestTimeout = max(35, (int)($options['telegram_request_timeout'] ?? 75));
        $this->forceIpv4 = (bool)($options['telegram_force_ipv4'] ?? true);
    }

    public function api(string $method, array $params = [], ?int $timeout = null): array
    {
        if (!$this->token || str_contains($this->token, 'PUT_YOUR')) {
            throw new RuntimeException('请先在 config.php 填写 telegram_bot_token');
        }
        $url = 'https://api.telegram.org/bot' . $this->token . '/' . $method;
        $ch = curl_init($url);
        $requestTimeout = $timeout !== null ? max(5, $timeout) : $this->requestTimeout;
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $params,
            CURLOPT_CONNECTTIMEOUT => $this->connectTimeout,
            CURLOPT_TIMEOUT => $requestTimeout,
            CURLOPT_NOSIGNAL => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        if ($this->forceIpv4 && defined('CURL_IPRESOLVE_V4')) {
            curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        }
        if ($this->proxy !== '') {
            curl_setopt($ch, CURLOPT_PROXY, $this->proxy);
        }
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $errno = curl_errno($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $err) {
            throw new RuntimeException('Telegram API 请求失败：curl#' . $errno . ' ' . $err);
        }
        $json = json_decode($body, true);
        if (!is_array($json)) {
            throw new RuntimeException('Telegram API 返回异常 HTTP ' . $httpCode . '：' . substr((string)$body, 0, 300));
        }
        if (!($json['ok'] ?? false)) {
            throw new RuntimeException('Telegram API 错误 HTTP ' . $httpCode . '：' . json_encode($json, JSON_UNESCAPED_UNICODE));
        }
        return $json;
    }

    public function sendMessage(string $chatId, string $text, ?array $keyboard = null, bool $disablePreview = true): void
    {
        $params = [
            'chat_id' => $chatId,
            'text' => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => $disablePreview ? 'true' : 'false',
        ];
        if ($keyboard !== null) $params['reply_markup'] = json_encode(['inline_keyboard' => $keyboard], JSON_UNESCAPED_UNICODE);
        $this->api('sendMessage', $params);
    }

    public function editMessageText(string $chatId, int $messageId, string $text, ?array $keyboard = null): void
    {
        $params = [
            'chat_id' => $chatId,
            'message_id' => $messageId,
            'text' => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => 'true',
        ];
        if ($keyboard !== null) $params['reply_markup'] = json_encode(['inline_keyboard' => $keyboard], JSON_UNESCAPED_UNICODE);
        $this->api('editMessageText', $params);
    }

    public function answerCallback(string $callbackId, string $text = ''): void
    {
        $this->api('answerCallbackQuery', ['callback_query_id' => $callbackId, 'text' => $text]);
    }
}
