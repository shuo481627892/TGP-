<?php
class Utils
{
    public static function now(): string
    {
        return date('Y-m-d H:i:s');
    }

    public static function h(?string $text): string
    {
        return htmlspecialchars((string)$text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function short(?string $value, int $left = 8, int $right = 6): string
    {
        $value = (string)$value;
        if (strlen($value) <= $left + $right + 3) return $value;
        return substr($value, 0, $left) . '...' . substr($value, -$right);
    }

    public static function normalizeChain(string $chain): ?string
    {
        $chain = strtoupper(trim($chain));
        $chain = str_replace([' ', '-', '_'], '', $chain);
        $map = [
            'ETH' => 'ETH', 'ETHEREUM' => 'ETH', 'ERC20' => 'ETH',
            'BSC' => 'BSC', 'BCS' => 'BSC', 'BNB' => 'BSC', 'BNBCHAIN' => 'BSC', 'BEP20' => 'BSC', 'BSCCHAIN' => 'BSC',
            'BTC' => 'BTC', 'BITCOIN' => 'BTC',
            'TRON' => 'TRON', 'TRX' => 'TRON', 'TRC20' => 'TRON', 'USDTTRC20' => 'TRON',
        ];
        return $map[$chain] ?? null;
    }

    public static function chainTitle(string $chain): string
    {
        return [
            'ETH' => 'Ethereum / ERC20',
            'BSC' => 'BNB Smart Chain / BEP20',
            'BTC' => 'Bitcoin',
            'TRON' => 'TRON / TRX / TRC20',
        ][$chain] ?? $chain;
    }

    public static function nativeSymbol(string $chain): string
    {
        return ['ETH' => 'ETH', 'BSC' => 'BNB', 'BTC' => 'BTC', 'TRON' => 'TRX'][$chain] ?? $chain;
    }

    public static function explorerUrl(string $chain, string $txid): string
    {
        switch ($chain) {
            case 'ETH': return 'https://etherscan.io/tx/' . $txid;
            case 'BSC': return 'https://bscscan.com/tx/' . $txid;
            case 'BTC': return 'https://blockstream.info/tx/' . $txid;
            case 'TRON': return 'https://tronscan.org/#/transaction/' . $txid;
            default: return $txid;
        }
    }

    public static function validateAddress(string $chain, string $address): bool
    {
        $address = trim($address);
        if ($chain === 'ETH' || $chain === 'BSC') {
            return (bool)preg_match('/^0x[a-fA-F0-9]{40}$/', $address);
        }
        if ($chain === 'BTC') {
            return (bool)preg_match('/^(bc1[ac-hj-np-z02-9]{25,90}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$/i', $address);
        }
        if ($chain === 'TRON') {
            return self::isValidTronAddress($address);
        }
        return false;
    }

    /**
     * 从用户文本中提取第一个链上地址，并返回可能所属链。
     * 注意：0x 地址在 ETH 与 BSC/BCS 上格式完全相同，无法只靠地址唯一判断，所以默认同时返回 ETH+BSC。
     */
    public static function detectAddressFromText(string $text): ?array
    {
        $text = trim($text);
        if ($text === '') return null;

        if (preg_match('/0x[a-fA-F0-9]{40}/', $text, $m)) {
            return ['address' => $m[0], 'chains' => ['ETH', 'BSC'], 'type' => 'EVM'];
        }
        if (preg_match_all('/(?<![1-9A-HJ-NP-Za-km-z])T[1-9A-HJ-NP-Za-km-z]{33}(?![1-9A-HJ-NP-Za-km-z])/', $text, $matches)) {
            foreach ($matches[0] as $candidate) {
                if (self::validateAddress('TRON', $candidate)) {
                    return ['address' => $candidate, 'chains' => ['TRON'], 'type' => 'TRON'];
                }
            }
            return null;
        }
        if (preg_match('/\b(?:bc1[ac-hj-np-z02-9]{25,90}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b/i', $text, $m)) {
            return ['address' => $m[0], 'chains' => ['BTC'], 'type' => 'BTC'];
        }
        return null;
    }

    public static function httpGetJson(string $url, array $headers = [], int $timeout = 20, string $proxy = ''): array
    {
        $ch = curl_init($url);
        $httpHeaders = ['Accept: application/json', 'User-Agent: LM-MultiChain-Telegram-Bot/1.4'];
        foreach ($headers as $key => $value) {
            if (is_int($key)) $httpHeaders[] = $value;
            else $httpHeaders[] = $key . ': ' . $value;
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_HTTPHEADER => $httpHeaders,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        if ($proxy !== '') {
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $err) {
            throw new RuntimeException('HTTP 请求失败：' . $err);
        }
        if ($code < 200 || $code >= 300) {
            throw new RuntimeException('HTTP 状态异常：' . $code . '，返回：' . substr($body, 0, 300));
        }
        $json = json_decode($body, true);
        if (!is_array($json)) {
            throw new RuntimeException('JSON 解析失败：' . substr($body, 0, 300));
        }
        return $json;
    }

    public static function httpPostJson(string $url, array $payload = [], array $headers = [], int $timeout = 20, string $proxy = ''): array
    {
        $ch = curl_init($url);
        $httpHeaders = ['Accept: application/json', 'Content-Type: application/json', 'User-Agent: LM-MultiChain-Telegram-Bot/1.4'];
        foreach ($headers as $key => $value) {
            if (is_int($key)) $httpHeaders[] = $value;
            else $httpHeaders[] = $key . ': ' . $value;
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_HTTPHEADER => $httpHeaders,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        if ($proxy !== '') {
            curl_setopt($ch, CURLOPT_PROXY, $proxy);
        }
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $err) {
            throw new RuntimeException('HTTP 请求失败：' . $err);
        }
        if ($code < 200 || $code >= 300) {
            throw new RuntimeException('HTTP 状态异常：' . $code . '，返回：' . substr($body, 0, 300));
        }
        $json = json_decode($body, true);
        if (!is_array($json)) {
            throw new RuntimeException('JSON 解析失败：' . substr($body, 0, 300));
        }
        return $json;
    }

    public static function decimalAmount(string $integer, int $decimals): string
    {
        $integer = preg_replace('/[^0-9]/', '', $integer) ?: '0';
        if ($decimals <= 0) return ltrim($integer, '0') ?: '0';
        $len = strlen($integer);
        if ($len <= $decimals) {
            $integer = str_pad($integer, $decimals + 1, '0', STR_PAD_LEFT);
            $len = strlen($integer);
        }
        $whole = substr($integer, 0, $len - $decimals);
        $frac = substr($integer, -$decimals);
        $frac = rtrim($frac, '0');
        $whole = ltrim($whole, '0') ?: '0';
        return $frac === '' ? $whole : $whole . '.' . $frac;
    }

    public static function btcAmount($sats): string
    {
        if (function_exists('bcdiv')) {
            return rtrim(rtrim(bcdiv((string)$sats, '100000000', 8), '0'), '.') ?: '0';
        }
        return rtrim(rtrim(number_format(((float)$sats) / 100000000, 8, '.', ''), '0'), '.') ?: '0';
    }

    public static function formatSigned(string $direction, string $amount): string
    {
        return ($direction === 'IN' ? '+' : '-') . $amount;
    }

    public static function uniqueKey(array $tx): string
    {
        return sha1(implode('|', [
            $tx['chain'] ?? '', $tx['address'] ?? '', $tx['txid'] ?? '', $tx['event_key'] ?? '',
            $tx['from_addr'] ?? '', $tx['to_addr'] ?? '', $tx['symbol'] ?? '', $tx['amount'] ?? ''
        ]));
    }

    public static function txTime(?int $timestamp): string
    {
        if (!$timestamp) return self::now();
        return date('Y-m-d H:i:s', $timestamp);
    }

    public static function formatBalanceValue(?string $balance, string $symbol): string
    {
        $balance = $balance === null || $balance === '' ? '0' : $balance;
        return $balance . ' ' . $symbol;
    }

    // ---------- TRON Base58Check helpers，纯 PHP + bcmath ----------
    private static string $alphabet = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

    public static function isValidTronAddress(string $address): bool
    {
        $address = trim($address);
        if (!preg_match('/^T[1-9A-HJ-NP-Za-km-z]{33}$/', $address)) return false;
        try {
            $hex = self::base58Decode($address);
            if (strlen($hex) !== 50) return false;
            $payload = strtoupper(substr($hex, 0, 42));
            $checksum = strtoupper(substr($hex, 42, 8));
            if (substr($payload, 0, 2) !== '41') return false;
            $bin = @hex2bin($payload);
            if ($bin === false) return false;
            $expected = strtoupper(substr(hash('sha256', hex2bin(hash('sha256', $bin))), 0, 8));
            return hash_equals($expected, $checksum);
        } catch (Throwable $e) {
            return false;
        }
    }

    public static function tronBase58ToHex(string $address): ?string
    {
        try {
            if (!self::isValidTronAddress($address)) return null;
            $hex = self::base58Decode($address);
            return strtoupper(substr($hex, 0, 42));
        } catch (Throwable $e) {
            return null;
        }
    }

    public static function tronHexToBase58(string $hex): string
    {
        $hex = strtoupper(preg_replace('/[^0-9A-Fa-f]/', '', $hex));
        if (strlen($hex) === 40) $hex = '41' . $hex;
        if (substr($hex, 0, 2) !== '41') return $hex;
        $checksum = substr(hash('sha256', hex2bin(hash('sha256', hex2bin($hex)))), 0, 8);
        return self::base58Encode($hex . $checksum);
    }

    public static function tronContractToHex(string $contract): ?string
    {
        $contract = trim($contract);
        if ($contract === '') return null;
        if (preg_match('/^T[1-9A-HJ-NP-Za-km-z]{33}$/', $contract)) {
            return self::tronBase58ToHex($contract);
        }
        $hex = strtoupper(preg_replace('/[^0-9A-Fa-f]/', '', $contract));
        if (strlen($hex) === 40) $hex = '41' . $hex;
        if (strlen($hex) === 42 && substr($hex, 0, 2) === '41') return $hex;
        return null;
    }

    private static function base58Decode(string $input): string
    {
        if (!function_exists('bcadd')) throw new RuntimeException('需要安装 PHP bcmath 扩展');
        $num = '0';
        for ($i = 0; $i < strlen($input); $i++) {
            $p = strpos(self::$alphabet, $input[$i]);
            if ($p === false) throw new RuntimeException('非法 Base58 字符');
            $num = bcadd(bcmul($num, '58', 0), (string)$p, 0);
        }
        $hex = self::decToHex($num);
        if (strlen($hex) % 2) $hex = '0' . $hex;
        $leading = 0;
        for ($i = 0; $i < strlen($input) && $input[$i] === '1'; $i++) $leading++;
        return str_repeat('00', $leading) . strtoupper($hex);
    }

    private static function base58Encode(string $hex): string
    {
        if (!function_exists('bcadd')) throw new RuntimeException('需要安装 PHP bcmath 扩展');
        $hex = strtolower($hex);
        $num = self::hexToDec($hex);
        $out = '';
        while (bccomp($num, '0', 0) > 0) {
            $rem = (int)bcmod($num, '58');
            $num = bcdiv($num, '58', 0);
            $out = self::$alphabet[$rem] . $out;
        }
        $leading = 0;
        for ($i = 0; $i + 1 < strlen($hex) && substr($hex, $i, 2) === '00'; $i += 2) $leading++;
        return str_repeat('1', $leading) . ($out ?: '1');
    }

    public static function hexToDec(string $hex): string
    {
        if (!function_exists('bcadd')) throw new RuntimeException('需要安装 PHP bcmath 扩展');
        $hex = strtolower(preg_replace('/[^0-9a-fA-F]/', '', $hex));
        if ($hex === '') return '0';
        $dec = '0';
        for ($i = 0; $i < strlen($hex); $i++) {
            $dec = bcadd(bcmul($dec, '16', 0), (string)hexdec($hex[$i]), 0);
        }
        return $dec;
    }

    private static function decToHex(string $dec): string
    {
        if (bccomp($dec, '0', 0) === 0) return '00';
        $hex = '';
        while (bccomp($dec, '0', 0) > 0) {
            $rem = (int)bcmod($dec, '16');
            $hex = dechex($rem) . $hex;
            $dec = bcdiv($dec, '16', 0);
        }
        return $hex;
    }
}
