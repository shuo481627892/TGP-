<?php
class DB
{
    private PDO $pdo;

    public function __construct(string $path)
    {
        $dir = dirname($path);
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $this->pdo = new PDO('sqlite:' . $path, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $this->pdo->exec('PRAGMA journal_mode=WAL');
        $this->migrate();
    }

    public function pdo(): PDO
    {
        return $this->pdo;
    }

    private function migrate(): void
    {
        $this->pdo->exec("CREATE TABLE IF NOT EXISTS users (
            chat_id TEXT PRIMARY KEY,
            user_id TEXT,
            username TEXT,
            first_name TEXT,
            state TEXT DEFAULT '',
            state_payload TEXT DEFAULT '',
            created_at TEXT,
            updated_at TEXT
        )");
        $this->pdo->exec("CREATE TABLE IF NOT EXISTS monitored_addresses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            label TEXT DEFAULT '',
            chat_id TEXT NOT NULL,
            user_id TEXT DEFAULT '',
            active INTEGER DEFAULT 1,
            created_at TEXT,
            updated_at TEXT,
            UNIQUE(chain, address, chat_id)
        )");
        $this->pdo->exec("CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            unique_key TEXT NOT NULL UNIQUE,
            chain TEXT NOT NULL,
            address TEXT NOT NULL,
            txid TEXT NOT NULL,
            event_key TEXT DEFAULT '',
            direction TEXT DEFAULT '',
            symbol TEXT DEFAULT '',
            amount TEXT DEFAULT '',
            from_addr TEXT DEFAULT '',
            to_addr TEXT DEFAULT '',
            block_time TEXT DEFAULT '',
            notified INTEGER DEFAULT 0,
            raw_json TEXT DEFAULT '',
            created_at TEXT
        )");
        $this->pdo->exec("CREATE INDEX IF NOT EXISTS idx_addr_active ON monitored_addresses(active, chain, address)");
        $this->pdo->exec("CREATE INDEX IF NOT EXISTS idx_tx_addr ON transactions(chain, address, txid)");
        $this->pdo->exec("CREATE TABLE IF NOT EXISTS monitor_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            level TEXT,
            message TEXT,
            created_at TEXT
        )");
    }

    public function upsertUser(array $from, string $chatId): void
    {
        $stmt = $this->pdo->prepare("INSERT INTO users(chat_id,user_id,username,first_name,created_at,updated_at)
            VALUES(:chat_id,:user_id,:username,:first_name,:created_at,:updated_at)
            ON CONFLICT(chat_id) DO UPDATE SET user_id=excluded.user_id, username=excluded.username, first_name=excluded.first_name, updated_at=excluded.updated_at");
        $stmt->execute([
            ':chat_id' => $chatId,
            ':user_id' => (string)($from['id'] ?? ''),
            ':username' => $from['username'] ?? '',
            ':first_name' => $from['first_name'] ?? '',
            ':created_at' => Utils::now(),
            ':updated_at' => Utils::now(),
        ]);
    }

    public function setState(string $chatId, string $state, string $payload = ''): void
    {
        $stmt = $this->pdo->prepare("UPDATE users SET state=:state,state_payload=:payload,updated_at=:updated_at WHERE chat_id=:chat_id");
        $stmt->execute([':state'=>$state, ':payload'=>$payload, ':updated_at'=>Utils::now(), ':chat_id'=>$chatId]);
    }

    public function getState(string $chatId): array
    {
        $stmt = $this->pdo->prepare("SELECT state,state_payload FROM users WHERE chat_id=?");
        $stmt->execute([$chatId]);
        return $stmt->fetch() ?: ['state'=>'', 'state_payload'=>''];
    }

    public function addAddress(string $chain, string $address, string $label, string $chatId, string $userId): int
    {
        $stmt = $this->pdo->prepare("INSERT INTO monitored_addresses(chain,address,label,chat_id,user_id,active,created_at,updated_at)
            VALUES(:chain,:address,:label,:chat_id,:user_id,1,:created_at,:updated_at)
            ON CONFLICT(chain,address,chat_id) DO UPDATE SET label=excluded.label, active=1, updated_at=excluded.updated_at");
        $stmt->execute([
            ':chain'=>$chain, ':address'=>$address, ':label'=>$label, ':chat_id'=>$chatId, ':user_id'=>$userId,
            ':created_at'=>Utils::now(), ':updated_at'=>Utils::now(),
        ]);
        $id = (int)$this->pdo->lastInsertId();
        if ($id === 0) {
            $q = $this->pdo->prepare("SELECT id FROM monitored_addresses WHERE chain=? AND address=? AND chat_id=?");
            $q->execute([$chain, $address, $chatId]);
            $id = (int)($q->fetch()['id'] ?? 0);
        }
        return $id;
    }

    public function listAddresses(string $chatId = '', bool $onlyActive = true): array
    {
        $sql = "SELECT * FROM monitored_addresses WHERE 1=1";
        $params = [];
        if ($chatId !== '') { $sql .= " AND chat_id=?"; $params[] = $chatId; }
        if ($onlyActive) { $sql .= " AND active=1"; }
        $sql .= " ORDER BY id DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function deactivateAddress(int $id, string $chatId = ''): bool
    {
        $sql = "UPDATE monitored_addresses SET active=0, updated_at=? WHERE id=?";
        $params = [Utils::now(), $id];
        if ($chatId !== '') { $sql .= " AND chat_id=?"; $params[] = $chatId; }
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->rowCount() > 0;
    }

    public function activeAddresses(): array
    {
        $stmt = $this->pdo->query("SELECT * FROM monitored_addresses WHERE active=1 ORDER BY id ASC");
        return $stmt->fetchAll();
    }

    public function insertTx(array $tx, int $notified = 0): bool
    {
        $tx['unique_key'] = $tx['unique_key'] ?? Utils::uniqueKey($tx);
        $stmt = $this->pdo->prepare("INSERT OR IGNORE INTO transactions(unique_key,chain,address,txid,event_key,direction,symbol,amount,from_addr,to_addr,block_time,notified,raw_json,created_at)
            VALUES(:unique_key,:chain,:address,:txid,:event_key,:direction,:symbol,:amount,:from_addr,:to_addr,:block_time,:notified,:raw_json,:created_at)");
        $stmt->execute([
            ':unique_key'=>$tx['unique_key'], ':chain'=>$tx['chain'], ':address'=>$tx['address'], ':txid'=>$tx['txid'],
            ':event_key'=>$tx['event_key'] ?? '', ':direction'=>$tx['direction'] ?? '', ':symbol'=>$tx['symbol'] ?? '', ':amount'=>$tx['amount'] ?? '',
            ':from_addr'=>$tx['from_addr'] ?? '', ':to_addr'=>$tx['to_addr'] ?? '', ':block_time'=>$tx['block_time'] ?? '',
            ':notified'=>$notified, ':raw_json'=>json_encode($tx['raw'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ':created_at'=>Utils::now(),
        ]);
        return $stmt->rowCount() > 0;
    }

    public function markNotified(string $uniqueKey): void
    {
        $stmt = $this->pdo->prepare("UPDATE transactions SET notified=1 WHERE unique_key=?");
        $stmt->execute([$uniqueKey]);
    }

    public function log(string $level, string $message): void
    {
        $stmt = $this->pdo->prepare("INSERT INTO monitor_logs(level,message,created_at) VALUES(?,?,?)");
        $stmt->execute([$level, $message, Utils::now()]);
    }

    public function stats(): array
    {
        return [
            'addresses' => (int)$this->pdo->query("SELECT COUNT(*) FROM monitored_addresses WHERE active=1")->fetchColumn(),
            'txs' => (int)$this->pdo->query("SELECT COUNT(*) FROM transactions")->fetchColumn(),
            'users' => (int)$this->pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
        ];
    }
}
