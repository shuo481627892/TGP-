# LM MultiChain Telegram Bot v1.6

版权：@Addliming

## v1.6 新增

- systemd 自动守护：bot.php / monitor.php 退出后自动重启。
- 心跳 watchdog：进程没有退出但卡死时，每分钟检测 `storage/*.heartbeat`，超过 180 秒不更新就自动重启对应服务。
- 支持开机自启。

## 安装/更新

```bash
cd /www/wwwroot/epay.lm888.shop
pkill -f "php bot.php" || true
pkill -f "php monitor.php" || true
php install.php
bash scripts/install_systemd.sh /www/wwwroot/epay.lm888.shop
```

## 查看状态

```bash
systemctl status lm-multichain-bot lm-multichain-monitor lm-multichain-watchdog.timer
```

## 查看日志

```bash
journalctl -u lm-multichain-bot -u lm-multichain-monitor -u lm-multichain-watchdog -f
```

## 手动测试 watchdog

```bash
bash scripts/watchdog.sh /www/wwwroot/epay.lm888.shop
```

## 原有功能

- Telegram 机器人批量添加监听地址。
- 自动识别 ETH / BSC / BTC / TRON / TRC20 地址。
- 用户发送地址自动查询余额。
- 监听地址发生收入或支出时，通知用户本次数量、转出地址、收入地址、当前余额和交易链接。
