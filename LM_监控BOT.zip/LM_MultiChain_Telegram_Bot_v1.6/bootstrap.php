<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle) { return $needle === '' || strpos($haystack, $needle) !== false; }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) { return $needle === '' || strpos($haystack, $needle) === 0; }
}

$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    $configFile = __DIR__ . '/config.example.php';
}
$config = require $configFile;
date_default_timezone_set($config['timezone'] ?? 'Asia/Singapore');

$requiredExtensions = ['curl', 'pdo_sqlite', 'json', 'bcmath'];
$missingExtensions = [];
foreach ($requiredExtensions as $ext) {
    if (!extension_loaded($ext)) $missingExtensions[] = $ext;
}
if ($missingExtensions) {
    throw new RuntimeException('缺少 PHP 扩展：' . implode(', ', $missingExtensions) . '。请在宝塔/服务器 PHP 扩展中安装后重试。');
}

require_once __DIR__ . '/src/Utils.php';
require_once __DIR__ . '/src/DB.php';
require_once __DIR__ . '/src/Telegram.php';
require_once __DIR__ . '/src/ChainProviders.php';
require_once __DIR__ . '/src/BotController.php';

$db = new DB($config['db_path']);
$telegram = new Telegram($config['telegram_bot_token'], $config['proxy'] ?? '', $config);
$providers = new ChainProviders($config);
$controller = new BotController($db, $telegram, $providers, $config);
